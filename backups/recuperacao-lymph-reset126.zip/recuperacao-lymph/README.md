# Lymph Reset Plan — recuperação da variante reset126-mf-comp

Origem [VictoryScale](https://victoryscale.com/lymph/reset126-mf-comp). A triagem retornou HTTP 200. A entrada é pré-renderizada com Next.js e os passos seguintes são conduzidos pelos bundles originais no navegador. A variante do caminho foi preservada. A cópia usa uma sessão local fictícia e dispensa parâmetros de clique ou de atribuição de anúncio.

## Como abrir a cópia

Extraia o ZIP, abra a pasta extraída no terminal e execute:

```sh
python serve.py
```

Abra [http://127.0.0.1:8775/lymph/reset126-mf-comp](http://127.0.0.1:8775/lymph/reset126-mf-comp) no computador em que executou o servidor. Para uma consulta visual sem servidor, abra os PNGs nas pastas `capture_*`. A página `/quiz` e os demais caminhos servem o HTML original arquivado. O checkout local usa o identificador fictício `00000000-0000-4000-8000-000000000001`. A navegação local bloqueia scripts e conexões externos. O servidor descarta as escritas e devolve respostas de demonstração. Use dados fictícios ao percorrer o espelho.

## Conteúdo recuperado

- `site/` contém HTML, chunks JS/CSS, imagens, fontes, página inicial, quiz, captação de nome/e-mail e consentimento, checkout, recibo, roteador de upsells e 22 páginas de upsell. As variantes de upsell são acessadas diretamente com a sessão fictícia para confirmar as telas. O backend comercial determina a sequência após pagamento em produção.
- Os documentos incluem termos, privacidade, assinatura e reembolso, uso aceitável e contato. Os termos identificam Solovista Limited, registro ΗΕ 480329, Arch. Makariou III, 1 MITSI BUILDING 3, 2nd Floor, Flat/Office 211, 1065, Nicosia, Cyprus, e `hello@victoryscale.com` como contato.
- O quiz exibe cinco faixas etárias e dois ramos de gênero. O indicador interno tem 33 etapas, entre perguntas, telas de informação, perfil e carregamento. A captação inclui o plano personalizado e um cartão raspável; o fluxo para no checkout antes de qualquer ação de pagamento.
- As 33 rotas arquivadas responderam HTTP 200 sem exceções JavaScript ou respostas locais de erro na verificação direta. Uma rota profunda de exemplo retornou HTTP 200 pelo fallback. A auditoria verificou 905 URLs próprias espelhadas. Foram excluídas referências literais de módulos internos e de templates que responderam 404 na origem. Imagens descobertas apenas em execução, como logos de pagamento e ilustrações de upsells, foram incluídas na segunda passagem.
- As páginas pós-compra são cópias de interfaces exibidas com dados fictícios. Um texto de pagamento bem-sucedido em uma captura representa a própria tela de recibo. Nenhuma cobrança foi executada.

## Scripts de verificação

```sh
python audit_assets.py
python mirror.py
python crawl.py
python verify_routes.py
```

O espelho usa `curl`. Os scripts de navegador precisam de Playwright para Python e Chromium. Instale com `python -m pip install playwright` e `python -m playwright install chromium` se necessário. No ambiente em que o espelho foi criado, o Chromium fica em `/workspace/scratch/ms-playwright` e pode ser selecionado com `PLAYWRIGHT_BROWSERS_PATH`. O servidor deve estar rodando para os dois scripts de navegador. Os dez percursos representativos chegaram ao checkout. Sete foram registrados antes de adicionar os simuladores de atribuição e Klaviyo e registram os dois 404 de telemetria sem bloquear a navegação. Três percursos foram repetidos com os simuladores finais e chegaram ao checkout sem erros locais. Os relatórios distinguem as rotas diretamente verificadas dos percursos do quiz. O crawler usa respostas fictícias representativas e não enumera todas as combinações de respostas de múltipla escolha.

## Operação e republicação

| Dependência | Evidência no código ou em execução |
| --- | --- |
| Sessão e captação | `POST /api-client-proxy/dynamic-public/session-new/session/v3` cria a sessão no fim do quiz. Sem backend ou simulador, o carregamento do plano não consegue avançar. `GET` e `PUT` no mesmo caminho com `/{uuid}` leem e atualizam a sessão. A cópia não persiste nome, e-mail ou respostas. |
| Funil e cartão | Os bundles contêm `GET /funnels/funnel` e configuração de oferta. A oferta exibida localmente foi validada com caminhos e valores de demonstração do código publicado. Preços finais, moeda, cupons e variações em produção podem depender da sessão e da configuração comercial. |
| Checkout e pós-compra | Os bundles contêm `POST /payments/v3/create-session`, `POST /payments/v3/update-session` e `POST /payments/yuno/create-payment`, além de referências a Primer e PayPal. `GET /api-client-proxy/dynamic-public/cart-v2/cart/v3/{uuid}` alimenta o recibo. O roteador de ofertas pós-compra chama `POST /api-client-proxy/dynamic-public/upsell-flow/upsell/v3/start`. A entrega ao app chama `POST /api/app-handoff`. As rotas de confirmação de pagamento e carga pós-compra não foram executadas. |
| Telemetria | `POST /api-client-proxy/realtime/events/track-event` foi observado no carregamento. O código inclui Google Tag Manager, Sentry com `sendDefaultPii` ativo e rotas de conversão para Meta, Google, TikTok, Pinterest, Snap e AppLovin. A presença no bundle não confirma disparo de todas as integrações nesta variante. Na prévia, o rastreamento externo é bloqueado e a API local de eventos descarta os dados. A atribuição solicita `GET /api-client-proxy/realtime/events/utm-data/{uuid}` e o fluxo de captação chama `POST /api-client-proxy/dynamic-public-direct/klaviyo/events`. Esses dois caminhos também têm respostas locais de demonstração. |
| Prefixo e rotas | A versão está vinculada ao prefixo `/lymph/reset126-mf-comp`, usado nos HTMLs do Next, geração de links legais, roteamento para quiz/captação/checkout e lógica comercial. Ao migrar, preserve esse prefixo ou revise esses pontos juntos. Os chunks, imagens e proxy usam caminhos na raiz. |

Para reativar a operação comercial, reconecte as contas originais de backend, pagamento, atendimento e atribuição. A hospedagem precisa servir os caminhos do Next, as páginas profundas e um backend para os endpoints usados. A cópia pública não contém código-fonte original de servidor, credenciais da conta, histórico de leads, recibos reais ou regras privadas de configuração. Este pacote preserva os arquivos compilados publicamente recuperáveis.
