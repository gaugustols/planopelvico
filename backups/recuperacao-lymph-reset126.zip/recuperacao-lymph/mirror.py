import argparse
from collections import deque
from concurrent.futures import ThreadPoolExecutor
from hashlib import sha256
from html import unescape
import json
from pathlib import Path
import re
import subprocess
from urllib.parse import parse_qsl, unquote, urlencode, urljoin, urlsplit, urlunsplit

ORIGIN = "https://victoryscale.com"
ROUTE = "/lymph/reset126-mf-comp"
ROOT = Path(__file__).resolve().parent
SITE = ROOT / "site"
PREVIEW_UUID = "00000000-0000-4000-8000-000000000001"
UPSELLS = ("calorie-tracker", "coach", "companion", "detox-diet",
           "fast-food-diet", "fasting-tracker", "lifetime", "vs-bundle")
PAGES = (
    ROUTE,
    *(f"{ROUTE}/{name}" for name in (
        "quiz", "terms-of-services", "privacy-policy",
        "subscription-and-refund-policy", "acceptable-use-policy", "contact-us")),
    *(f"{ROUTE}/{name}/{PREVIEW_UUID}" for name in ("email", "checkout", "thank-you", "up")),
    *(f"{ROUTE}/up/{PREVIEW_UUID}/{name}{suffix}"
      for name in UPSELLS
      for suffix in (("",) if name == "companion" else ("", "-us", "-usa-st"))),
)
EXTENSIONS = r"js|mjs|css|woff2?|ttf|png|jpe?g|webp|avif|svg|gif|json|mp4|webm|mp3|ico"
FILES = re.compile(rf"""(?P<ref>(?:https?://[^/\s"'<>]+)?/(?:[\w@.%+~-]+/)*[\w@.%+~-]+\.(?:{EXTENSIONS})(?:\?[^\s"'<>(),;\\]+)?|(?:\.{{1,2}}/|(?:static|assets|images|img|videos|media)/)(?:[\w@.%+~-]+/)*[\w@.%+~-]+\.(?:{EXTENSIONS})(?:\?[^\s"'<>(),;\\]+)?)\b""", re.I)
OPTIMIZED = re.compile(r'/_next/image\?[^\s"\x27<>\\,]+')
CSS_URL = re.compile(r'url\(\s*["\x27]?([^\s"\x27)]+)')
TEXT_EXTENSIONS = {".html", ".css", ".js", ".mjs", ".json"}


def canonical(url):
    parts = urlsplit(url)
    query = urlencode(sorted((key, val) for key, val in parse_qsl(parts.query)
                             if key != "dpl")) if parts.path == "/_next/image" else ""
    return urlunsplit((parts.scheme, parts.netloc, parts.path, query, ""))


def destination(url):
    parts = urlsplit(canonical(url))
    path = unquote(parts.path).lstrip("/")
    if parts.path == "/_next/image":
        return SITE / "_next" / "image-cache" / sha256(parts.query.encode()).hexdigest()
    if path and Path(path).suffix:
        result = SITE / path
    else:
        result = SITE / path / "index.html"
    if not result.resolve().is_relative_to(SITE.resolve()):
        raise ValueError(f"Invalid path: {url}")
    return result


def references(url, source):
    clean = unescape(source.replace(r'\"', '"').replace(r"\u0026", "&").replace(r"\/", "/"))
    refs = {m["ref"] for m in FILES.finditer(clean)
            if "/node_modules/" not in m["ref"]
            and not re.fullmatch(r"\./locale/[a-z-]+\.js", m["ref"])
            and not (m.start() and clean[m.start() - 1] == "}"
                    and "${" in clean[max(0, m.start() - 90):m.start()])}
    refs.update(OPTIMIZED.findall(clean))
    if urlsplit(url).path.endswith(".css"):
        refs.update(ref for ref in CSS_URL.findall(clean)
                    if not ref.startswith(("data:", "#")))
    result = set()
    for ref in refs:
        if ref.startswith("static/"):
            ref = "/_next/" + ref
        elif ref.startswith(("assets/", "img/", "images/", "videos/", "media/")):
            ref = "/" + ref
        items = urlsplit(urljoin(url, ref))
        if items.scheme == "https" and items.netloc == urlsplit(ORIGIN).netloc:
            candidate = canonical(items.geturl())
            if not items.path.startswith(("/api/", "//")):
                result.add(candidate)
    return result


def initial_urls():
    paths = {ORIGIN + page for page in PAGES}
    paths.update(f"{ORIGIN}/assets/checkout/{name}" for name in (
        "press-forbes.svg", "press-businessinsider.svg", "pay-visa.webp",
        "pay-mastercard.webp", "pay-amex.svg", "pay-maestro.webp"))
    log = ROOT / "network.json"
    if log.exists():
        paths.update(canonical(item["url"]) for item in json.loads(log.read_text())
                     if item["type"] in {"script", "stylesheet", "image", "font", "media"}
                     and item["method"] == "GET"
                     and urlsplit(item["url"]).netloc == urlsplit(ORIGIN).netloc)
    return paths


def download(url, refresh=False):
    dest = destination(url)
    if dest.is_file() and not refresh:
        return url, 200
    dest.parent.mkdir(parents=True, exist_ok=True)
    temp = dest.with_name(dest.name + ".download")
    response = subprocess.run(
        ["curl", "-sS", "--retry", "2", "--max-time", "45", "-o", str(temp),
         "-w", "%{http_code} %{content_type}", url],
        capture_output=True, text=True)
    fields = response.stdout.split(" ", 1)
    status = int(fields[0]) if fields[0].isdigit() else 0
    media = fields[1] if len(fields) > 1 else ""
    if status == 200 and not (media.startswith("text/html") and dest.suffix != ".html"):
        temp.replace(dest)
    else:
        temp.unlink(missing_ok=True)
        status = status if status != 200 else "unexpected HTML"
    return url, status


def source_refs(url):
    path = destination(url)
    if path.is_file() and path.suffix in TEXT_EXTENSIONS:
        return references(url, path.read_text(errors="replace"))
    return set()


def main():
    parser = argparse.ArgumentParser(description="Recover publicly served quiz assets.")
    parser.add_argument("--refresh", action="store_true")
    args = parser.parse_args()
    pending = deque(sorted(initial_urls()))
    seen = set(pending)
    statuses = {}
    with ThreadPoolExecutor(max_workers=12) as workers:
        while pending:
            batch = [pending.popleft() for _ in range(min(len(pending), 36))]
            for url, status in workers.map(lambda url: download(url, args.refresh), batch):
                statuses[url] = status
                if status == 200:
                    new = source_refs(url) - seen
                    seen.update(new)
                    pending.extend(sorted(new))
    (ROOT / "mirror-status.json").write_text(json.dumps(statuses, indent=2) + "\n")
    print(f"{sum(status == 200 for status in statuses.values())}/{len(statuses)} URLs espelhadas")


if __name__ == "__main__":
    main()
