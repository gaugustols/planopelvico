import argparse
from pathlib import Path
import json
import re
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright

from mirror import ROOT, ROUTE

AGES = ["30-39", "40-49", "50-59", "60+", "I’m 18-29"]


def capture(page, folder, step, text, buttons):
    stem = folder / f"{step:02}"
    stem.with_suffix(".html").write_text(page.content())
    stem.with_suffix(".txt").write_text(text)
    stem.with_suffix(".json").write_text(json.dumps(
        {"path": urlsplit(page.url).path, "buttons": buttons}, ensure_ascii=False, indent=2))
    page.screenshot(path=stem.with_suffix(".png"), animations="disabled", full_page=True)


def reveal_discount(page, canvas):
    canvas.scroll_into_view_if_needed()
    box = canvas.bounding_box()
    if not box:
        return
    left, top = box["x"], box["y"]
    width, height = box["width"], box["height"]
    page.mouse.move(left + 15, top + height * 0.25)
    page.mouse.down()
    for i, y in enumerate((0.25, 0.5, 0.75)):
        page.mouse.move(left + (width - 15 if i % 2 == 0 else 15), top + height * y, steps=9)
    page.mouse.up()
    page.wait_for_timeout(850)


def walk(browser, base, age, gender, diagnostics, screenshots):
    folder = ROOT / f"capture_validado_idade{age+1}_{gender.lower()}"
    if screenshots:
        folder.mkdir(exist_ok=True)
    context = browser.new_context(viewport={"width": 430, "height": 932}, is_mobile=True,
                                  has_touch=True, service_workers="block")
    netloc = urlsplit(base).netloc
    context.route("**/*", lambda route: route.continue_()
                  if urlsplit(route.request.url).netloc == netloc else route.abort())
    page = context.new_page()
    requests, errors = [], []
    page.on("response", lambda r: requests.append((r.request.method, r.request.resource_type, r.status, r.url)))
    page.on("pageerror", lambda error: errors.append(str(error)))
    steps = []
    try:
        page.goto(base + ROUTE)
        for i in range(65):
            page.wait_for_timeout(330)
            if "/checkout/" in urlsplit(page.url).path:
                page.get_by_role("button", name="Get my plan", exact=True).first.wait_for(timeout=8000)
                page.wait_for_function("document.body.innerText.includes('Get my plan')", timeout=8000)
            text = page.locator("body").inner_text()
            buttons = page.locator("button:visible")
            labels = [label.strip() for label in buttons.all_inner_texts()]
            fields = page.locator("input:visible").evaluate_all(
                "(els) => els.map(e => ({type:e.type,placeholder:e.placeholder,value:e.value}))")
            path = urlsplit(page.url).path
            state = {"path": path, "text": text, "buttons": labels, "fields": fields}
            steps.append(state)
            print(age, gender, i, path, text[:115].replace("\n", " "), labels[:16], fields, flush=True)
            if screenshots:
                capture(page, folder, i, text, labels)
            if i == 0:
                page.get_by_role("button", name=AGES[age], exact=True).click(timeout=5000)
                page.get_by_text("Who is this plan for?", exact=True).wait_for(timeout=6000)
                continue
            if i == 1:
                buttons.nth(labels.index(gender)).click(timeout=5000)
                page.get_by_text("Continue", exact=True).wait_for(timeout=6000)
                continue
            if re.search(r"checkout|payment", path, re.I) or any(
                    "card" in field["placeholder"].lower() for field in fields):
                break
            if "/email/" in path:
                email = page.get_by_placeholder("Your email", exact=True)
                name = page.get_by_placeholder("Your name", exact=True)
                decline = page.get_by_role("button", name=re.compile(r"No thanks", re.I))
                if email.is_visible() or name.is_visible():
                    if email.is_visible():
                        email.fill("preview@example.invalid")
                    else:
                        name.fill("Preview")
                    page.get_by_role("button", name="Continue", exact=True).click(timeout=4500)
                elif decline.is_visible():
                    decline.click(timeout=4500)
                elif "Continue" in labels or "Claim it" in labels:
                    buttons.nth(labels.index("Continue" if "Continue" in labels else "Claim it")).click(timeout=4500)
                elif (canvas := page.locator("canvas.cursor-pointer")).count() and not labels:
                    reveal_discount(page, canvas.first)
                elif any("discount" in label.lower() or "plan" in label.lower() for label in labels):
                    buttons.nth(next(j for j, label in enumerate(labels)
                                     if "discount" in label.lower() or "plan" in label.lower())).click(timeout=4500)
                else:
                    page.wait_for_timeout(1400)
                continue
            if i > 1 and labels and all(steps[-2][key] == state[key] for key in ("path", "text", "buttons")):
                state["stalled"] = True
                break
            for field in fields:
                if field["type"] in ("text", "number", "tel") and not field["value"]:
                    placeholder = field["placeholder"]
                    value = "170" if "cm" in text.lower() else "80" if "kg" in text.lower() else "45"
                    if placeholder:
                        page.get_by_placeholder(placeholder, exact=True).first.fill(value)
            advance = next((j for j, label in enumerate(labels)
                            if re.fullmatch(r"(continue|next|go on|get started|start|got it|see my plan|yes,? continue)[!.]?", label, re.I)), None)
            option = next((j for j, label in enumerate(labels)
                           if label and label.lower() not in ("back", "skip", "menu")), None)
            if advance is not None and not buttons.nth(advance).is_enabled() and option != advance:
                buttons.nth(option).click(timeout=3500)
                buttons.nth(advance).click(timeout=3500)
            elif advance is not None:
                buttons.nth(advance).click(timeout=3500)
            elif option is not None:
                buttons.nth(option).click(timeout=3500)
            else:
                page.wait_for_timeout(1700)
    except Exception as error:
        errors.append(str(error))
        print("ERRO", error, flush=True)
    finally:
        diagnostics.append({"age": AGES[age], "gender": gender, "steps": steps,
                            "errors": errors, "requests": requests})
        context.close()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--base", default="http://127.0.0.1:8775")
    parser.add_argument("--age", type=int, choices=range(5))
    parser.add_argument("--gender", choices=["Male", "Female"])
    parser.add_argument("--report", default="crawl-report.json")
    parser.add_argument("--no-captures", action="store_true")
    args = parser.parse_args()
    if urlsplit(args.base).hostname not in {"127.0.0.1", "localhost", "::1"}:
        parser.error("O teste exige um servidor local")
    diagnostics = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        for age in range(5) if args.age is None else [args.age]:
            for gender in [args.gender] if args.gender else ["Female", "Male"]:
                walk(browser, args.base.rstrip("/"), age, gender, diagnostics, not args.no_captures)
        browser.close()
    (ROOT / args.report).write_text(json.dumps(diagnostics, ensure_ascii=False, indent=2))
    return int(any(
        item["errors"] or not item["steps"] or "/checkout/" not in item["steps"][-1]["path"]
        or any(status >= 400 for _, _, status, _ in item["requests"])
        for item in diagnostics
    ))


if __name__ == "__main__":
    raise SystemExit(main())
