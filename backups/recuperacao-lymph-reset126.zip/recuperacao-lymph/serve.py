import argparse
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
import json
import mimetypes
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

from mirror import ORIGIN, PREVIEW_UUID, ROUTE, SITE, destination


class Handler(SimpleHTTPRequestHandler):
    server_version = "Lymph-Recovery/1.0"

    def __init__(self, *args, **kwargs):
        super().__init__(*args, directory=str(SITE), **kwargs)

    def end_headers(self):
        self.send_header("Content-Security-Policy",
                         "default-src 'self'; script-src 'self' 'unsafe-inline'; "
                         "style-src 'self' 'unsafe-inline'; img-src 'self' data: blob:; "
                         "connect-src 'self'; frame-src 'none'; form-action 'self'")
        super().end_headers()

    def send_head(self):
        if urlsplit(self.path).path == "/":
            self.send_response(302)
            self.send_header("Location", ROUTE)
            self.end_headers()
            return None
        return super().send_head()

    def translate_path(self, path):
        parts = urlsplit(path)
        if parts.path == "/_next/image":
            cached = destination(ORIGIN + path)
            if cached.is_file():
                return str(cached)
            image = parse_qs(parts.query).get("url", [""])[0]
            if image.startswith("/images/"):
                return super().translate_path(image)
        local = Path(super().translate_path(path))
        if local.is_dir() and (local / "index.html").is_file():
            return str(local / "index.html")
        if not local.exists() and (
            parts.path == ROUTE or parts.path.startswith(ROUTE + "/")
        ) and not local.suffix:
            return str(SITE / ROUTE.lstrip("/") / "index.html")
        return str(local)

    def guess_type(self, path):
        if "/_next/image-cache/" in path:
            with open(path, "rb") as f:
                head = f.read(16)
            if head.startswith(b"\x89PNG"):
                return "image/png"
            if head.startswith(b"\xff\xd8"):
                return "image/jpeg"
            if head[8:12] == b"WEBP":
                return "image/webp"
            if head[4:12] == b"ftypavif":
                return "image/avif"
        return mimetypes.guess_type(path)[0] or "application/octet-stream"

    session_root = "/api-client-proxy/dynamic-public/session-new/session/v3"
    session_url = f"{session_root}/{PREVIEW_UUID}"
    session_body = {"data": {"uuid": PREVIEW_UUID, "id": PREVIEW_UUID}}

    def send_json(self, data):
        payload = json.dumps(data).encode()
        self.send_response(200)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

    def do_GET(self):
        path = urlsplit(self.path).path
        fixtures = {
            self.session_url: self.session_body,
            f"/api-client-proxy/realtime/events/utm-data/{PREVIEW_UUID}": {"data": {}},
            "/api/session/get-country": {"country": "US"},
            f"/api-client-proxy/dynamic-public/cart-v2/cart/v3/{PREVIEW_UUID}": {"data": []},
        }
        if path in fixtures:
            self.send_json(fixtures[path])
        else:
            super().do_GET()

    def accept_fixture(self, fixtures):
        path = urlsplit(self.path).path
        try:
            size = int(self.headers.get("Content-Length", "0"))
        except ValueError:
            self.send_error(400)
            return
        if path not in fixtures or not 0 <= size <= 1024 * 1024:
            self.send_error(404)
            return
        self.rfile.read(size)
        self.send_json(fixtures[path])

    def do_POST(self):
        self.accept_fixture({
            "/api-client-proxy/realtime/events/track-event": {},
            "/api-client-proxy/dynamic-public-direct/klaviyo/events": {},
            self.session_root: self.session_body,
            "/api/app-handoff": {},
            "/api-client-proxy/dynamic-public/upsell-flow/upsell/v3/start": {"data": None},
        })

    def do_PUT(self):
        self.accept_fixture({self.session_url: self.session_body})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--port", type=int, default=8775)
    parser.add_argument("--host", default="127.0.0.1")
    args = parser.parse_args()
    with ThreadingHTTPServer((args.host, args.port), Handler) as server:
        print(f"Preview: http://{args.host}:{args.port}{ROUTE}", flush=True)
        server.serve_forever()


if __name__ == "__main__":
    main()
