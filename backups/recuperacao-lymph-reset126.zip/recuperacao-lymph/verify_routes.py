import json
from urllib.parse import urlsplit

from playwright.sync_api import sync_playwright

from mirror import PAGES, PREVIEW_UUID, ROOT, ROUTE

BASE = "http://127.0.0.1:8775"


def main():
    results = []
    with sync_playwright() as playwright:
        browser = playwright.chromium.launch()
        for path in PAGES:
            context = browser.new_context(viewport={"width": 430, "height": 932},
                                          is_mobile=True, has_touch=True, service_workers="block")
            context.route("**/*", lambda route: route.continue_()
                          if urlsplit(route.request.url).netloc == urlsplit(BASE).netloc else route.abort())
            page = context.new_page()
            errors = []
            missing = []
            page.on("pageerror", lambda error: errors.append(str(error)))
            page.on("response", lambda response: missing.append(
                [response.request.method, response.request.resource_type, response.status, response.url])
                if response.status >= 400 else None)
            response = page.goto(BASE + path, wait_until="load")
            page.wait_for_timeout(500)
            text = page.locator("body").inner_text()
            if PREVIEW_UUID in path:
                label = path.removeprefix(ROUTE + "/").replace("/" + PREVIEW_UUID, "").replace("/", "-")
                folder = ROOT / "capture_rotas" / label
                folder.mkdir(parents=True, exist_ok=True)
                (folder / "page.html").write_text(page.content())
                (folder / "page.txt").write_text(text)
                page.screenshot(path=folder / "page.png", animations="disabled", full_page=True)
            result = {"path": path, "status": response.status, "final_url": page.url,
                      "errors": errors, "missing": missing, "heading": text.splitlines()[:4]}
            results.append(result)
            print(path, response.status, len(errors), len(missing), flush=True)
            context.close()
        browser.close()
    (ROOT / "route-report.json").write_text(json.dumps(results, ensure_ascii=False, indent=2))
    return int(any(result["status"] != 200 or result["errors"] or result["missing"] for result in results))


if __name__ == "__main__":
    raise SystemExit(main())
