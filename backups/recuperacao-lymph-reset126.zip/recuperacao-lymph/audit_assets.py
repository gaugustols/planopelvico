import json

from mirror import ROOT, destination, initial_urls, source_refs


def main():
    statuses = json.loads((ROOT / "mirror-status.json").read_text())
    referenced = initial_urls()
    for url in statuses:
        referenced.update(source_refs(url))
    missing = sorted(url for url in referenced if not destination(url).is_file())
    print(f"Referências: {len(referenced)} | presentes: {len(referenced) - len(missing)} | faltam: {len(missing)}")
    for url in missing:
        print(statuses.get(url, "sem resposta registrada"), url)
    return bool(missing)


if __name__ == "__main__":
    raise SystemExit(main())
